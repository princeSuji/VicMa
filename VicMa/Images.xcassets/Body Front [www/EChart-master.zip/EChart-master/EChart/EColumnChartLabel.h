//
//  EColumnChartLabel.h
//  EChart
//
//  Created by Efergy China on 13/12/13.
//  Copyright (c) 2013 Scott Zhu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EColumnChartLabel : UILabel

@end
