//
//  EColor.m
//  EChart
//
//  Created by Efergy China on 12/12/13.
//  Copyright (c) 2013 Scott Zhu. All rights reserved.
//

#import "EColor.h"

@implementation EColor
-(id)init{
    if (self = [super init]) {
        
        
    }
    return self;
}


@end
